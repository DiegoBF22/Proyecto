from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

def novedades(request):
  return JsonResponse([
      {
        "id": 1,
        "Name": "GTA V",
        "Img":"https://www.figma.com/community/icon?resource_id=736000994034548392&resource_type=plugin",
        "OurScore":93,
        "ProfesionalScore":95,
        "UserScore":90
      },
      {
        "id": 1,
        "Name": "GTA VI",
        "Img":"https://www.figma.com/community/icon?resource_id=736000994034548392&resource_type=plugin",
        "OurScore":93,
        "ProfesionalScore":95,
        "UserScore":90
      },
      {
        "id": 1,
        "Name": "GTA VII",
        "Img":"https://www.figma.com/community/icon?resource_id=736000994034548392&resource_type=plugin",
        "OurScore":100,
        "ProfesionalScore":100,
        "UserScore":90
      }], safe=False)

def estrategiaJuegos(request):
  return JsonResponse([{
        "id": 1,
        "Name": "GTA V",
        "Price": 59.99,
        "Author": "RockStar",
        "Gender":"A1A2",
        "Img":"https://www.figma.com/community/icon?resource_id=736000994034548392&resource_type=plugin",
        "Trailer":"ijosdjdsadsa.video",
        "Description":"Es un juego donde puedes hacer muchas cosas",
        "Guide":"fhiofdhfdsifdsfdsfdsfds.video",
        "EnlacesCompra":"jdkiosndjdsanjdsanjdsa",
        "Release":"17-09-2013",
        "OurScore":93,
        "ProfesionalScore":95,
        "UserScore":90
      },
      {
        "id": 1,
        "Name": "Mordhau",
        "Price": 19.99,
        "Author": "RockStar",
        "Gender":"A1A2",
        "Img":"https://www.figma.com/community/icon?resource_id=736000994034548392&resource_type=plugin",
        "Trailer":"ijosdjdsadsa.video",
        "Description":"Es un juego donde puedes hacer muchas cosas",
        "Guide":"fhiofdhfdsifdsfdsfdsfds.video",
        "EnlacesCompra":"jdkiosndjdsanjdsanjdsa",
        "Release":"17-09-2013",
        "OurScore":93,
        "ProfesionalScore":95,
        "UserScore":90
      }], safe=False)

@csrf_exempt
def login_logout(request):
  if request.method == "PATCH":
    token = request.headers.get("SessionToken", None)
    if token is None:
      return JsonResponse({"error": "Missing Token"}, status=401)
    return JsonResponse({"status": "success"})
  elif request.method == "POST":
    return JsonResponse({"sessionToken": "abc", "Privilege": True}, status=201)
  else:
    return JsonResponse({"error": "No mandaste un PATCH ni un POST"}, status=405)
  
def juegoPorId(request):
  return JsonResponse({
        "id": 1,
        "Name": "GTA V",
        "Price": 59.99,
        "Author": "RockStar",
        "Gender":"A1A2",
        "Img":"https://www.figma.com/community/icon?resource_id=736000994034548392&resource_type=plugin",
        "Trailer":"https://www.youtube.com/watch?v=dQw4w9WgXcQ",
        "Description":"Es un juego donde puedes hacer muchas cosas",
        "Guide":"fhiofdhfdsifdsfdsfdsfds.video",
        "EnlaceCompra":"jdkiosndjdsanjdsanjdsa",
        "Release":"17-09-2013",
        "OurScore":93,
        "ProfesionalScore":95,
        "UserScore":90
      })
      
def reviewsDeJuegoPorId(request):
  if request.method == "GET":
    return JsonResponse([{
            "idUser":"Alejandro",
            "Comment":"No me gustan en particular este tipo de juegos pero  no está mal, hay bastante contenido que se puede hacer sobre ",
            "Score":85,
            "Type":"User",
            "UserImg": "https://www.figma.com/community/icon?resource_id=736000994034548392&resource_type=plugin",
            "Date":"17-12-2023"
        }], safe=False)
  elif request.method == "POST":
    token = request.headers.get("SessionToken", None)
    if token is None:
      return JsonResponse({"error": "Missing Token"}, status=401)
    return JsonResponse({"status": "ok, subida, JAJA no"}, status=201)

def criticasDeJuegoPorId(request):
  return JsonResponse([{
            "idUser":"Diego",
            "Comment":"VAYA JUEGO!",
            "UserImg": "https://www.figma.com/community/icon?resource_id=736000994034548392&resource_type=plugin",
            "Date":"17-12-2023"
        }], safe=False)
        
def noticias(request):
  return JsonResponse([{
            "id":1,
            "Title":"Noticia",
            "Description":"No me gustan en particular este tipo de juegos pero no está mal, hay bastante contenido que se puede hacer sobre ",
            "img":"https://www.figma.com/community/icon?resource_id=736000994034548392&resource_type=plugin",
            "Date":"17-12-2023"
        },
        {
            "id":1,
            "Title":"Noticia",
            "Description":"No me gustan en particular este tipo de juegos pero no está mal, hay bastante contenido que se puede hacer sobre ",
            "img":"https://www.figma.com/community/icon?resource_id=736000994034548392&resource_type=plugin",
            "Date":"17-12-2023"
        }], safe=False)

def publicacionesDeJuego(request):
  if request.method == "GET":
    return JsonResponse([{
   "title":"XXXXXXXXX",
   "subtitle":"XXXXXXXX",
   "Publication":"No me gustan en particular este tipo de juegos pero no está mal, hay bastant contenido que se puede hacer sobre ",
   "img":"https://www.figma.com/community/icon?resource_id=736000994034548392&resource_type=plugin",
   "Date":"17-12-2023",
   "NombreAutor":"XX",
   "FotoPerfilAutor":"XX",
   "DescAutor":"XXXXXXX"},
   {
   "title":"XXXXXXXXX",
   "subtitle":"XXXXXXXX",
   "Publication":"No me gustan en particular este tipo de juegos pero no está mal, hay bastant contenido que se puede hacer sobre ",
   "img":"https://www.figma.com/community/icon?resource_id=736000994034548392&resource_type=plugin",
   "Date":"17-12-2023",
   "NombreAutor":"XX",
   "FotoPerfilAutor":"XX",
   "DescAutor":"XXXXXXX"}], safe=False)
  elif request.method == "POST":
    token = request.headers.get("SessionToken", None)
    if token is None:
      return JsonResponse({"error": "Missing Token"}, status=401)
    return JsonResponse({"status": "Added (well, yes, but actually, no)"}, status=201)

def detallePublicacion(request):
  token = request.headers.get("SessionToken", None)
  if token is None:
    return JsonResponse({"error": "Missing Token"}, status=401)
  return JsonResponse({
   "title":"XXXXXXXXX",
   "subtitle":"XXXXXXXX",
   "Publication":"No me gustan en particular este tipo de juegos pero no está mal, hay bastant contenido que se puede hacer sobre ",
   "img":"https://www.figma.com/community/icon?resource_id=736000994034548392&resource_type=plugin",
   "Date":"17-12-2023",
   "Privileged":True,
   "NombreAutor":"XX",
   "FotoPerfilAutor":"XX",
   "DescAutor":"XXXXXXX"})
 
def detallePublicacionComentarios(request):
  return JsonResponse([{
   "FotoPerfilUser":"https://www.figma.com/community/icon?resource_id=736000994034548392&resource_type=plugin",
   "NameTag":"Pablo",
   "Comment":"No me gustan en particular este tipo de juegos pero no está mal, hay bastante contenido que se puede hacer sobre ",
   "Date":"17-12-2023"
   },
   {
   "FotoPerfilUser":"https://www.figma.com/community/icon?resource_id=736000994034548392&resource_type=plugin",
   "NameTag":"Pablo",
   "Comment":"No me gustan en particular este tipo de juegos pero no está mal, hay bastante contenido que se puede hacer sobre ",
   "Date":"17-12-2023"
   }], safe=False)
   
def subirComentario(request):
  if request.method != "POST":
    return JsonResponse({"error": "Método HTTP no soportado"}, status=405)
  token = request.headers.get("SessionToken", None)
  if token is None:
    return JsonResponse({"error": "Missing Token"}, status=401)
  return JsonResponse({"status": "ok"}, status=201)
  
def perfilUsuario(request):
  token = request.headers.get("SessionToken", None)
  if token is None:
    return JsonResponse({"error": "Missing Token"}, status=401)
  return JsonResponse({
        "NameTag": "XXXXXXX",
        "ImgPerfil": "https://www.figma.com/community/icon?resource_id=736000994034548392&resource_type=plugin",
        "RegAccount": "01-01-1990",
        "Description":"XXXXXXXX",
        "Valoraciones":10,
        "MediaVal":55,
        "FollowerStatus":"Nfollowing"
      })

def perfilUsuarioComentarios(request):
  return JsonResponse([{
       "PublicTitle":"XXXXXXXXX",
       "Comment":"No me gustan en particular este tipo de juegos pero no está mal, hay bastante contenido que se puede hacer sobre ",
       "Date":"17-12-2023"
       }], safe=False)

def perfilUsuarioValoraciones(request):
  return JsonResponse([{
       "PublicTitle":"XXXXXXXXX",
       "Comment":"No me gustan en particular este tipo de juegos pero no está mal, hay bastante contenido que se puede hacer sobre ",
       "Date":"17-12-2023",
       "Score": 99,
       "GameImg": "https://www.figma.com/community/icon?resource_id=736000994034548392&resource_type=plugin"
       }], safe=False)

def follow_unfollow(request):
  token = request.headers.get("SessionToken", None)
  if token is None:
    return JsonResponse({"error": "Missing Token"}, status=401)
  if request.method != "PUT" and request.method != "DELETE":
    return JsonResponse({"error": "Not a PUT or DELETE"}, status=405)
  return JsonResponse({"status": "ok"})

def perfilDeveloper(request):
  token = request.headers.get("SessionToken", None)
  if token is None:
    return JsonResponse({"error": "Missing Token"}, status=401)
  return JsonResponse({
        "NameTag": "XXXXXXX",
        "ImgPerfil": "https://www.figma.com/community/icon?resource_id=736000994034548392&resource_type=plugin",
        "RegAccount": "01-01-1990",
        "Description":"XXXXXXXX",
        "Lanzamientos":10,
        "MediaVal":55,
        "FollowerStatus":"following"
      })

def perfilDeveloperJuegos(request):
  return JsonResponse([{
       "GameTitle":"XXXXXXXXX",
       "Description":"bla bla",
       "Date":"17-12-2023",
       "Image": "https://www.figma.com/community/icon?resource_id=736000994034548392&resource_type=plugin"
       }], safe=False)
     
def publicarJuego(request):
  if request.method != "POST":
    return JsonResponse({"error": "Método HTTP no soportado"}, status=405)
  token = request.headers.get("SessionToken", None)
  if token is None:
    return JsonResponse({"error": "Missing Token"}, status=401)
  return JsonResponse({"status": "ok"}, status=201)

def perfilPrensa(request):
  token = request.headers.get("SessionToken", None)
  if token is None:
    return JsonResponse({"error": "Missing Token"}, status=401)
  return JsonResponse({
        "NameTag": "XXXXXXX",
        "ImgPerfil": "https://www.figma.com/community/icon?resource_id=736000994034548392&resource_type=plugin",
        "RegAccount": "01-01-1990",
        "Description":"XXXXXXXX",
        "JuegosCriticados":100000,
        "MediaVal":55,
        "FollowerStatus":"user"
      })

def perfilPrensaCriticas(request):
  return JsonResponse([{
       "GameTitle":"XXXXXXXXX",
       "Description":"bla bla",
       "Date":"17-12-2023",
       "Image": "https://www.figma.com/community/icon?resource_id=736000994034548392&resource_type=plugin"
       }], safe=False)
     
def seguidores(request):
  return JsonResponse([{
    "id_Follower":"Diego",
    "description": "XXXXXX",
    "Img": "https://www.figma.com/community/icon?resource_id=736000994034548392&resource_type=plugin"}], safe=False)
    
def registro(request):
  if request.method !="POST":
    return JsonResponse({"error": "sorry"}, status=405)
  return JsonResponse({"status": "registrado"}, status=201)
