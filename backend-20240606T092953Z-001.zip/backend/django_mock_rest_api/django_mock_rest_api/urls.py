"""
URL configuration for django_mock_rest_api project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from rest_api import fake_endpoints

urlpatterns = [
    path('admin/', admin.site.urls),
    
    path('tJuegos/novedades', fake_endpoints.novedades),
    path('tGeneros/estrategia/juegos', fake_endpoints.estrategiaJuegos),
    path('tUsuarios/login', fake_endpoints.login_logout),
    path('tJuegos/1', fake_endpoints.juegoPorId),
    path('tValoraciones/1', fake_endpoints.reviewsDeJuegoPorId),
    path('tComentarios/1', fake_endpoints.criticasDeJuegoPorId),
    path('tNoticias', fake_endpoints.noticias),
    path('tJuegos/1/publicaciones', fake_endpoints.publicacionesDeJuego),
    path('tPublicaciones/1', fake_endpoints.detallePublicacion),
    path('tComentarios', fake_endpoints.subirComentario),
    path('tUsuarios/fabio', fake_endpoints.perfilUsuario),
    path('tUsuarios/fabio/comentarios', fake_endpoints.perfilUsuarioComentarios),
    path('tUsuarios/fabio/valoraciones', fake_endpoints.perfilUsuarioValoraciones),
    path('tFollowers/fabio', fake_endpoints.follow_unfollow),
    path('Developer/alejandro', fake_endpoints.perfilDeveloper),
    path('Developer/alejandro/juegos', fake_endpoints.perfilDeveloperJuegos),
    path('tJuegos', fake_endpoints.publicarJuego),
    path('Prensa/diego', fake_endpoints.perfilPrensa),
    path('Prensa/diego/criticas', fake_endpoints.perfilPrensaCriticas),
    path('tUsuarios/fabio/followers', fake_endpoints.seguidores),
    path('tUsuarios', fake_endpoints.registro)
]
